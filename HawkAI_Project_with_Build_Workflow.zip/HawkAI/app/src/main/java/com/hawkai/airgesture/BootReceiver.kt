package com.hawkai.airgesture

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.hawkai.airgesture.Prefs.autoStart
import com.hawkai.airgesture.Prefs.wantRunning

/** Restarts gesture detection after reboot / app update when the user left it on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (context.autoStart && context.wantRunning) {
            // Android 14+ may refuse to start a camera service from the background;
            // if so, the user just opens the app once and taps Start.
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, GestureService::class.java))
            }
        }
    }
}
